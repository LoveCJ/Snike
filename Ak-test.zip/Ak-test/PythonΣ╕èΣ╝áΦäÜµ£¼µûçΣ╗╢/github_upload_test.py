# =============================================
# 脚本名称：github_upload_test.py
# 功能：自动化上传本地文件到 GitHub 仓库
# 作者：万赢
# =============================================

import os
import time
import platform
import logging
import subprocess
import requests
import zipfile
import io
import getpass
import threading
from concurrent.futures import ThreadPoolExecutor
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

def get_chrome_version():
    try:
        if platform.system() == 'Darwin':  # 这个里判断macOS
            process = subprocess.Popen(['/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', '--version'], stdout=subprocess.PIPE)
            version = process.communicate()[0].decode('UTF-8').strip().split()[-1]
            return version
    except Exception as e:
        logger.error(f"获取 Chrome 版本时出错打印异常: {str(e)}")
    return None

def download_chromedriver(version):
    try:
        chrome_version = version.split('.')[0]
        download_url = f"https://edgedl.me.gvt1.com/edgedl/chrome/chrome-for-testing/{version}/mac-arm64/chromedriver-mac-arm64.zip"
        logger.info(f"开始下载 ChromeDriver: {download_url}")
        response = requests.get(download_url)
        if response.status_code == 200:
            with zipfile.ZipFile(io.BytesIO(response.content)) as zip_file:
                zip_file.extractall()
            chromedriver_path = os.path.join(os.getcwd(), 'chromedriver-mac-arm64', 'chromedriver')
            if os.path.exists(chromedriver_path):
                os.system(f'sudo mv {chromedriver_path} /usr/local/bin/')
                os.system('sudo chmod +x /usr/local/bin/chromedriver')
                logger.info("ChromeDriver 安装完成，这里只要存在就完成")
                return True
        else:
            logger.error(f"下载 ChromeDriver 失败: HTTP {response.status_code}")
    except Exception as e:
        logger.error(f"下载 ChromeDriver 时出错: {str(e)}")
    return False

def wait_for_internet_connection(max_retries=5, retry_delay=10):
    for attempt in range(max_retries):
        try:
            response = requests.get("https://github.com", timeout=10)
            if response.status_code < 400:
                logger.info("网络连接正常")
                return True
        except requests.RequestException:
            pass
        logger.warning("网络连接检查失败)")
        time.sleep(retry_delay)
    return False

class GitHubUploadTester:
    def __init__(self, max_workers=7):  # 默认同时处理10个文件
        logger.info("初始化 GitHub 上传测试器...")
        self.github_username = input("请输入 GitHub 用户名: ").strip()
        self.github_password = getpass.getpass("请输入 GitHub 密码（输入时不显示）: ").strip()
        self.repo_name = input("请输入仓库名yourrepo ").strip()
        self.max_workers = max_workers
        if not all([self.github_username, self.github_password, self.repo_name]):
            logger.error("账户、密码或仓库名输入不完整！")
            raise ValueError("缺少必要的登录信息")
        if not wait_for_internet_connection(max_retries=3, retry_delay=15):
            logger.error("无法建立网络连接，请检查：")
            raise ConnectionError("无法建立网络连接，请检查网络设置")

    def create_driver(self):
        """创建新的浏览器实例"""
        chrome_options = Options()
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.binary_location = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
        chrome_version = get_chrome_version()
        if chrome_version:
            logger.info(f"检测到 Chrome 版本: {chrome_version}")
            if download_chromedriver(chrome_version):
                service = Service('/usr/local/bin/chromedriver')
            else:
                raise Exception("无法下载匹配的 ChromeDriver")
        else:
            raise Exception("无法获取 Chrome 版本")
        driver = webdriver.Chrome(service=service, options=chrome_options)
        # 最大化浏览器窗口
        driver.maximize_window()
        return driver

    def process_single_file(self, file_path):
        """处理单个文件的上传"""
        driver = None
        try:
            driver = self.create_driver()
            wait = WebDriverWait(driver, 20)
            
            # 登录
            logger.info(f"正在处理文件: {file_path}")
            driver.get('https://github.com/login')
            username_field = wait.until(EC.presence_of_element_located((By.ID, "login_field")))
            username_field.send_keys(self.github_username)
            password_field = driver.find_element(By.ID, "password")
            password_field.send_keys(self.github_password)
            login_button = driver.find_element(By.NAME, "commit")
            login_button.click()
            time.sleep(5)

            # 上传文件
            repo_url = f'https://github.com/{self.github_username}/{self.repo_name}'
            driver.get(repo_url)
            time.sleep(3)
            add_file_button = wait.until(
                EC.element_to_be_clickable((By.XPATH, "//button[.//span[contains(text(), 'Add file')]]"))
            )
            add_file_button.click()
            upload_files_button = wait.until(
                EC.element_to_be_clickable((By.XPATH, "//a[contains(@href, '/upload/') and contains(., 'Upload files')]"))
            )
            upload_files_button.click()
            file_input = wait.until(
                EC.presence_of_element_located((By.XPATH, "//input[@type='file']"))
            )
            file_input.send_keys(os.path.abspath(file_path))
            time.sleep(8)
            commit_button = wait.until(
                EC.element_to_be_clickable((By.XPATH, "//button[contains(text(), 'Commit changes') and @type='submit']"))
            )
            commit_button.click()
            time.sleep(8)
            logger.info(f"文件 {file_path} 上传完成")
            
        except Exception as e:
            logger.error(f"处理文件 {file_path} 时出错: {str(e)}")
            if driver:
                screenshot_path = os.path.join(os.getcwd(), f'error_screenshot_{file_path.replace("/", "_")}.png')
                driver.save_screenshot(screenshot_path)
                logger.error(f"已保存错误截图到: {screenshot_path}")
        finally:
            if driver:
                driver.quit()

    def test_files(self, file_list):
        if not file_list:
            logger.error("没有提供要测试的文件列表！")
            return
        logger.info(f"开始并行测试 {len(file_list)} 个文件，最大并行数: {self.max_workers}")
        try:
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                executor.map(self.process_single_file, file_list)
        except Exception as e:
            logger.error(f"测试过程中出错: {str(e)}")
        logger.info("所有文件测试完成")

def main():
    test_files = []
    try:
        with open('test_files.txt', 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    test_files.append(line)
    except FileNotFoundError:
        logger.error("找不到 test_files.txt 文件！")
        return
    except Exception as e:
        logger.error(f"读取测试文件列表时出错: {str(e)}")
        return
    if not test_files:
        logger.error("没有找到有效的测试文件！请检查 test_files.txt 文件")
        return
    logger.info(f"已加载 {len(test_files)} 个测试文件")
    try:
        # 默认使用3个并行线程，可以根据需要调整
        tester = GitHubUploadTester(max_workers=3)
        tester.test_files(test_files)
    except Exception as e:
        logger.error(f"程序执行出错: {str(e)}")

if __name__ == "__main__":
    main() 