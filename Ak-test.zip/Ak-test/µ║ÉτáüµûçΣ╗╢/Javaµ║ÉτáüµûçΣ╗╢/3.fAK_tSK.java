这是测试的aksk，无风险，泄漏不会有风险。。

public class Main {
    public static void main(String[] args) {
        System.out.printf("Hello and welcome!\n");
        String AccessId= "LTAI8tEt8c9By8hQ8p8qBKrF";
        String AccessKey= "1NvihL4mdfL9piR9iqNTVCQWrXUEOe";
        if(AccessId !=null && AccessKey != null)
        {
            System.out.println(AccessId);
            System.out.println(AccessKey);
        }
    }
}