text-aksk
这是测试的aksk，无风险，泄漏不会有风险。。

base64编码
public class Main {
    public static void main(String[] args) {
        System.out.printf("Hello and welcome!\n");
        String AccessId= "TFRBSTV0RXQyYzhCeTloUTdwOXFCS3JR";
        String AccessKey= "MU52aWhMNG1kZkw5cGlSOWlxTlRWQ1FXclhVRU9l";
        if(AccessId !=null && AccessKey != null)
        {
            System.out.println(AccessId);
            System.out.println(AccessKey);
        }
    }
}

accessID=TFRBSTV0RXQyYzhCeTloUTdwOXFCS3JR
accesskey=MU52aWhMNG1kZkw5cGlSOWlxTlRWQ1FXclhVRU9l
